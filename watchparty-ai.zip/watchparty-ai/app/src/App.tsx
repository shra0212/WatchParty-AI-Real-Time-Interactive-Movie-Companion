import React, { useCallback, useRef, useState } from 'react';
import { StyleSheet, View, Pressable } from 'react-native';
import WatchPartyDrawer from './components/WatchPartyDrawer';
// import { VideoPlayer } from '@amazon-devices/react-native-w3cmedia'; // Vega media player

const TITLE_ID = 'demo'; // matches s3://<bucket>/demo/subtitles.srt

export default function App() {
  const [open, setOpen] = useState(false);
  const positionRef = useRef(0); // update from the player's time-update event
  const getTime = useCallback(() => positionRef.current, []);

  return (
    <View style={styles.root}>
      {/* Replace with the Vega player; call positionRef.current = currentTime on timeupdate */}
      <Pressable style={styles.video} onPress={() => setOpen((o) => !o)} />
      <WatchPartyDrawer titleId={TITLE_ID} getTime={getTime} open={open} onClose={() => setOpen(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  video: { flex: 1 },
});
