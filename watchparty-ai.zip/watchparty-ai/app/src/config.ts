export const API_URL = 'https://YOUR_API_ID.execute-api.us-east-1.amazonaws.com/Prod/ask';
export const DRAWER_WIDTH_RATIO = 0.3; // right 30% of the screen
