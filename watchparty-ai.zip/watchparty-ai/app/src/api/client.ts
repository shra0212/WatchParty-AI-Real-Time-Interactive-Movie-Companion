import { API_URL } from '../config';
import { AskResponse, Mode } from '../types';

export async function askWatchParty(
  titleId: string, timestampSec: number, mode: Mode, query = '',
): Promise<AskResponse> {
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ titleId, timestampSec, mode, query }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error ?? `HTTP ${res.status}`);
  return json;
}
