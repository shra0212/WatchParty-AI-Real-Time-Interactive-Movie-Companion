export type Mode = 'ask' | 'catchup' | 'actors';
export interface Actor { id: number; name: string; character: string; knownFor?: string[] }
export interface AskResponse { mode: Mode; answer?: string; bullets?: string[]; actors?: Actor[]; error?: string }
