import { useCallback, useState } from 'react';

/**
 * Voice adapter. Wire this to the Vega / Fire TV voice SDK (Alexa voice input
 * delivered as a text utterance). Kept behind one interface so the drawer
 * doesn't care where the transcript comes from.
 * `onUtterance` is invoked with the recognised text.
 */
export function useVoice(onUtterance: (text: string) => void) {
  const [listening, setListening] = useState(false);

  const start = useCallback(() => {
    setListening(true);
    // TODO: call the Vega voice API here and, on result:
    //   setListening(false); onUtterance(result.text);
  }, [onUtterance]);

  const stop = useCallback(() => setListening(false), []);
  return { listening, start, stop };
}
