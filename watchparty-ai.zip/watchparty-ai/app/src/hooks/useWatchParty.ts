import { useCallback, useState } from 'react';
import { askWatchParty } from '../api/client';
import { Actor, Mode } from '../types';

/** `getTime` must return the player's CURRENT position in seconds at call time,
 *  so the timestamp sent is the moment the question is asked. */
export function useWatchParty(titleId: string, getTime: () => number) {
  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState('');
  const [bullets, setBullets] = useState<string[]>([]);
  const [actors, setActors] = useState<Actor[]>([]);
  const [error, setError] = useState('');

  const run = useCallback(async (mode: Mode, query = '') => {
    setLoading(true); setError('');
    try {
      const r = await askWatchParty(titleId, getTime(), mode, query);
      if (mode === 'ask') setAnswer(r.answer ?? '');
      if (mode === 'catchup') setBullets(r.bullets ?? []);
      if (mode === 'actors') setActors(r.actors ?? []);
    } catch (e: any) {
      setError(e.message ?? 'Something went wrong');
    } finally { setLoading(false); }
  }, [titleId, getTime]);

  return { loading, answer, bullets, actors, error, run };
}
