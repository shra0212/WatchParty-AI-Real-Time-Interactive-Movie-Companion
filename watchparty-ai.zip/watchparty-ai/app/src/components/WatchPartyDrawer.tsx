import React, { useEffect, useRef, useState } from 'react';
import {
  Animated, Dimensions, Easing, Pressable, ScrollView, StyleSheet, Text, TextInput, View,
} from 'react-native';
import { DRAWER_WIDTH_RATIO } from '../config';
import { useWatchParty } from '../hooks/useWatchParty';
import { useVoice } from '../hooks/useVoice';

interface Props { titleId: string; getTime: () => number; open: boolean; onClose: () => void }

const W = Dimensions.get('window').width * DRAWER_WIDTH_RATIO;

function FocusButton({ label, onPress, preferred }: { label: string; onPress: () => void; preferred?: boolean }) {
  const [focused, setFocused] = useState(false);
  return (
    <Pressable
      onPress={onPress}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      hasTVPreferredFocus={preferred}
      style={[s.btn, focused && s.btnFocused]}
    >
      <Text style={s.btnText}>{label}</Text>
    </Pressable>
  );
}

export default function WatchPartyDrawer({ titleId, getTime, open, onClose }: Props) {
  const x = useRef(new Animated.Value(W)).current;
  const [query, setQuery] = useState('');
  const { loading, answer, bullets, actors, error, run } = useWatchParty(titleId, getTime);
  const voice = useVoice((text) => { setQuery(text); run('ask', text); });

  useEffect(() => {
    Animated.timing(x, {
      toValue: open ? 0 : W, duration: 250, easing: Easing.out(Easing.cubic), useNativeDriver: true,
    }).start();
  }, [open, x]);

  return (
    <Animated.View
      pointerEvents={open ? 'auto' : 'none'}
      style={[s.drawer, { width: W, transform: [{ translateX: x }] }]}
    >
      <Text style={s.title}>WatchParty AI</Text>
      <View style={s.row}>
        <FocusButton label="Catch Me Up" preferred onPress={() => run('catchup')} />
        <FocusButton label="Who's on screen" onPress={() => run('actors')} />
      </View>
      <View style={s.row}>
        <FocusButton label={voice.listening ? 'Listening…' : '🎤 Ask'} onPress={voice.listening ? voice.stop : voice.start} />
        <FocusButton label="Close" onPress={onClose} />
      </View>
      <TextInput
        style={s.input} value={query} onChangeText={setQuery}
        placeholder="Ask about the story so far…" placeholderTextColor="#888"
        onSubmitEditing={() => run('ask', query)}
      />
      <ScrollView style={s.body}>
        {loading && <Text style={s.text}>Thinking…</Text>}
        {!!error && <Text style={[s.text, { color: '#ff7b7b' }]}>{error}</Text>}
        {!!answer && <Text style={s.text}>{answer}</Text>}
        {bullets.map((b, i) => <Text key={i} style={s.text}>• {b}</Text>)}
        {actors.map((a) => (
          <Text key={a.id} style={s.text}>
            {a.name} as {a.character}{a.knownFor?.length ? ` — also in ${a.knownFor.join(', ')}` : ''}
          </Text>
        ))}
      </ScrollView>
    </Animated.View>
  );
}

const s = StyleSheet.create({
  drawer: { position: 'absolute', right: 0, top: 0, bottom: 0, backgroundColor: 'rgba(15,17,26,0.94)', padding: 24 },
  title: { color: '#fff', fontSize: 28, fontWeight: '700', marginBottom: 16 },
  row: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  btn: { paddingVertical: 10, paddingHorizontal: 16, borderRadius: 8, backgroundColor: '#2a2f45', borderWidth: 3, borderColor: 'transparent' },
  btnFocused: { borderColor: '#4da3ff', backgroundColor: '#3a4165' },
  btnText: { color: '#fff', fontSize: 20 },
  input: { color: '#fff', fontSize: 20, borderBottomWidth: 1, borderBottomColor: '#555', marginVertical: 12 },
  body: { flex: 1 },
  text: { color: '#e6e8f0', fontSize: 22, lineHeight: 30, marginBottom: 10 },
});
