# WatchParty AI — Real-Time Interactive Movie Companion

Fire TV / Vega OS app + AWS backend. The AI only ever sees subtitle text up to the viewer's current timestamp.

```
Fire TV (video + RN drawer) -> API Gateway -> Lambda (Context Resolver) -> Bedrock (Claude Sonnet/Haiku)
```

## Layout
- `backend/lambda/subtitles.py` – SRT/VTT parser + `cues_until(t)` (the spoiler gate)
- `backend/lambda/context_resolver.py` – loads subtitles/meta/scenes from S3, TMDB cast
- `backend/lambda/handler.py` – `POST /ask` with `mode`: `ask | catchup | actors`
- `backend/template.yaml` – SAM stack (API Gateway, Lambda, S3, Bedrock IAM)
- `app/` – React Native drawer (30% right overlay, remote-focus buttons, voice hook)

## Run
```
cd backend && python -m unittest discover tests      # spoiler-guard tests
sam build && sam deploy --guided --parameter-overrides TmdbApiKey=<key>
aws s3 cp sample/demo.srt s3://<BucketName>/demo/subtitles.srt
echo '{"title":"Demo Film","tmdbId":123}' | aws s3 cp - s3://<BucketName>/demo/meta.json
```
Put the `AskUrl` output into `app/src/config.ts`.

## Content per title (S3)
`<titleId>/subtitles.srt|vtt`, `meta.json` (`title`, `tmdbId`), optional `scenes.json`
(`[{"start":0,"end":95,"cast":[<tmdb person ids>]}]`) powering the Actor & Scene Spotter.

## Notes
- Bedrock model IDs are env-configurable (`MODEL_SONNET`, `MODEL_HAIKU`); enable model access in your region.
- `useVoice.ts` is an adapter stub: connect it to the Vega voice SDK.
- Player hookup in `App.tsx` is a placeholder: set `positionRef` from the Vega player's time updates.
- REST only for now; WebSocket can reuse `handler.py` logic behind an API Gateway WebSocket route.
