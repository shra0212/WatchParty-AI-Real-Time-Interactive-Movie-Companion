import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lambda"))
from subtitles import parse_subtitles, cues_until, cues_between, render

RAW = open(os.path.join(os.path.dirname(__file__), "..", "sample", "demo.srt")).read()


class Spoiler(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(len(parse_subtitles(RAW)), 3)

    def test_no_future_text(self):
        out = render(cues_until(parse_subtitles(RAW), 6 * 60))
        self.assertIn("lighthouse", out)
        self.assertNotIn("sold us out", out)

    def test_vtt(self):
        vtt = "WEBVTT\n\n00:01.000 --> 00:02.500\n<i>Hello</i>\n"
        self.assertEqual(parse_subtitles(vtt)[0].text, "Hello")

    def test_window(self):
        c = cues_between(parse_subtitles(RAW), 0, 60)
        self.assertEqual(len(c), 1)


if __name__ == "__main__":
    unittest.main()
