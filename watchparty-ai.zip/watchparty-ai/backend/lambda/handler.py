import json
import re
from subtitles import fmt
import context_resolver as ctx
import prompts
from bedrock_client import converse

HEADERS = {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}


def _resp(code: int, body: dict):
    return {"statusCode": code, "headers": HEADERS, "body": json.dumps(body)}


def lambda_handler(event, _context):
    try:
        body = json.loads(event.get("body") or "{}")
        title_id = str(body["titleId"])
        t = float(body["timestampSec"])
        mode = body.get("mode", "ask")
        query = str(body.get("query", ""))[:500]
        if t < 0 or mode not in ("ask", "catchup", "actors"):
            raise ValueError("bad input")
    except (KeyError, ValueError, TypeError, json.JSONDecodeError):
        return _resp(400, {"error": "Expected titleId, timestampSec>=0, mode in ask|catchup|actors"})

    meta = ctx.load_meta(title_id)
    title, ts = meta.get("title", title_id), fmt(t)
    cues = ctx.load_cues(title_id)
    if not cues:
        return _resp(404, {"error": "No subtitles found for this title"})

    if mode == "catchup":
        excerpt = ctx.transcript_window(cues, t, minutes=10)
        text = converse(
            prompts.system_prompt(title, ts, prompts.CATCHUP),
            f"Transcript (last 10 minutes, up to {ts}):\n{excerpt}",
            fast=True, max_tokens=250,
        )
        bullets = [re.sub(r"^[-*•]\s*", "", l).strip() for l in text.splitlines() if l.strip()][:3]
        return _resp(200, {"mode": mode, "bullets": bullets})

    if mode == "actors":
        cast = ctx.on_screen_cast(title_id, t, meta)
        return _resp(200, {"mode": mode, "actors": cast})

    transcript = ctx.transcript_so_far(cues, t)
    answer = converse(
        prompts.system_prompt(title, ts),
        f"Transcript up to {ts}:\n{transcript}\n\nViewer question: {query}",
    )
    return _resp(200, {"mode": mode, "answer": answer})
