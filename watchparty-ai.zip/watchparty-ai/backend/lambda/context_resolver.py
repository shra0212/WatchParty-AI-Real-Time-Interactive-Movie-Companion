"""Context Resolver: builds the spoiler-safe context for a (title, timestamp) pair."""
import json
import os
import boto3
from subtitles import parse_subtitles, cues_until, cues_between, render
import tmdb

_s3 = boto3.client("s3")
BUCKET = os.environ.get("CONTENT_BUCKET", "")


def _read(key: str) -> str | None:
    try:
        return _s3.get_object(Bucket=BUCKET, Key=key)["Body"].read().decode("utf-8")
    except _s3.exceptions.NoSuchKey:
        return None


def load_cues(title_id: str):
    for ext in ("srt", "vtt"):
        raw = _read(f"{title_id}/subtitles.{ext}")
        if raw:
            return parse_subtitles(raw)
    return []


def load_meta(title_id: str) -> dict:
    """meta.json: {"title": "...", "tmdbId": 123}"""
    raw = _read(f"{title_id}/meta.json")
    return json.loads(raw) if raw else {"title": title_id}


def on_screen_cast(title_id: str, t: float, meta: dict) -> list[dict]:
    """scenes.json (optional): [{"start":0,"end":95,"cast":[<tmdb person ids>]}].
    Only scenes that have started by `t` are considered, so a late-introduced actor
    is never revealed early. Without scene metadata we return nothing rather than
    guess (a full cast list could itself spoil who appears later)."""
    raw = _read(f"{title_id}/scenes.json")
    if not raw or not meta.get("tmdbId"):
        return []
    scenes = [s for s in json.loads(raw) if s["start"] <= t <= s["end"]]
    ids = {pid for s in scenes for pid in s.get("cast", [])}
    cast = [c for c in tmdb.movie_cast(meta["tmdbId"], limit=40) if c["id"] in ids]
    for c in cast:
        c["knownFor"] = tmdb.person_known_for(c["id"], meta["tmdbId"])
    return cast


def transcript_so_far(cues, t: float) -> str:
    return render(cues_until(cues, t))


def transcript_window(cues, t: float, minutes: int = 10) -> str:
    return render(cues_between(cues, max(0, t - minutes * 60), t))
