import os
import boto3

_client = boto3.client("bedrock-runtime", region_name=os.environ.get("BEDROCK_REGION", "us-east-1"))

# Override via env if a model ID is retired/replaced in your region.
SONNET = os.environ.get("MODEL_SONNET", "anthropic.claude-3-5-sonnet-20241022-v2:0")
HAIKU = os.environ.get("MODEL_HAIKU", "anthropic.claude-3-5-haiku-20241022-v1:0")


def converse(system: str, user: str, fast: bool = False, max_tokens: int = 400) -> str:
    resp = _client.converse(
        modelId=HAIKU if fast else SONNET,
        system=[{"text": system}],
        messages=[{"role": "user", "content": [{"text": user}]}],
        inferenceConfig={"maxTokens": max_tokens, "temperature": 0.3},
    )
    return resp["output"]["message"]["content"][0]["text"].strip()
