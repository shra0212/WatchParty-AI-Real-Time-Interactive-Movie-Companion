"""SRT / VTT parsing and timestamp-gated windowing (the core spoiler guardrail)."""
import re
from dataclasses import dataclass

_TS = re.compile(
    r"(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{3})\s*-->\s*(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{3})"
)
_TAGS = re.compile(r"<[^>]+>|\{\\an?\d\}")


@dataclass(frozen=True)
class Cue:
    start: float
    end: float
    text: str


def _secs(h, m, s, ms) -> float:
    return int(h or 0) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000.0


def parse_subtitles(raw: str) -> list[Cue]:
    cues: list[Cue] = []
    for block in re.split(r"\n\s*\n", raw.replace("\r\n", "\n").strip()):
        lines = block.split("\n")
        for i, line in enumerate(lines):
            m = _TS.search(line)
            if m:
                g = m.groups()
                text = " ".join(_TAGS.sub("", l).strip() for l in lines[i + 1:] if l.strip())
                if text:
                    cues.append(Cue(_secs(*g[0:4]), _secs(*g[4:8]), text))
                break
    cues.sort(key=lambda c: c.start)
    return cues


def cues_until(cues: list[Cue], t_current: float) -> list[Cue]:
    """ONLY cues that have already started. Nothing later ever reaches the LLM."""
    return [c for c in cues if c.start <= t_current]


def cues_between(cues: list[Cue], t_from: float, t_to: float) -> list[Cue]:
    return [c for c in cues if t_from <= c.start <= t_to]


def fmt(t: float) -> str:
    t = int(t)
    return f"{t // 3600:02d}:{(t % 3600) // 60:02d}:{t % 60:02d}"


def render(cues: list[Cue], max_chars: int = 24000) -> str:
    """Render cues as '[HH:MM:SS] line', keeping the most recent text if too long."""
    out = [f"[{fmt(c.start)}] {c.text}" for c in cues]
    text = "\n".join(out)
    return text[-max_chars:] if len(text) > max_chars else text
