"""TMDB helpers. Cast data is kept spoiler-safe: names, character names and
earlier-career credits only - never biography text or plot fields."""
import json
import os
import urllib.request

_BASE = "https://api.themoviedb.org/3"
_KEY = os.environ.get("TMDB_API_KEY", "")


def _get(path: str) -> dict:
    req = urllib.request.Request(f"{_BASE}{path}?api_key={_KEY}")
    with urllib.request.urlopen(req, timeout=4) as r:
        return json.loads(r.read())


def movie_cast(tmdb_id: int, limit: int = 12) -> list[dict]:
    if not _KEY:
        return []
    data = _get(f"/movie/{tmdb_id}/credits")
    return [
        {"id": c["id"], "name": c["name"], "character": c.get("character", "")}
        for c in data.get("cast", [])[:limit]
    ]


def person_known_for(person_id: int, exclude_tmdb_id: int, limit: int = 3) -> list[str]:
    if not _KEY:
        return []
    data = _get(f"/person/{person_id}/movie_credits")
    cast = sorted(data.get("cast", []), key=lambda c: c.get("popularity", 0), reverse=True)
    return [c["title"] for c in cast if c["id"] != exclude_tmdb_id][:limit]
